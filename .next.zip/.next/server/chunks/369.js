"use strict";
exports.id = 369;
exports.ids = [369];
exports.modules = {

/***/ 1369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(901);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var vanilla_tilt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5177);
/* harmony import */ var vanilla_tilt__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(vanilla_tilt__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const ArticleHeroSection = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ArticleSection__ArticleHeroSection",
  componentId: "sc-m6osfd-0"
})(["padding:5.2rem 0;", " @media screen and (max-width:960px){padding:3rem 0;}"], {
  "--tw-bg-opacity": "1",
  "backgroundColor": "rgba(248, 255, 244, var(--tw-bg-opacity))"
});
const ArticleHeroRow = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ArticleSection__ArticleHeroRow",
  componentId: "sc-m6osfd-1"
})(["display:flex;margin-right:-15px;margin-bottom:-15px;margin-left:-15px;flex-wrap:wrap;align-content:stretch;align-items:center;flex-direction:", ";"], ({
  imgStart
}) => imgStart === "start" ? "row-reverse" : "row");
const ArticleHeroCol = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ArticleSection__ArticleHeroCol",
  componentId: "sc-m6osfd-2"
})(["margin-bottom:15px;padding-right:15px;padding-left:15px;flex:1;max-width:50%;flex-basis:50%;@media screen and (max-width:960px){max-width:100%;flex-basis:100%;}"]);
const ArticleHeroH1 = styled_components__WEBPACK_IMPORTED_MODULE_1___default().h1.withConfig({
  displayName: "ArticleSection__ArticleHeroH1",
  componentId: "sc-m6osfd-3"
})(["", " font-weight:850;line-height:104px;@media screen and (max-width:960px){line-height:1;}"], {
  "fontSize": "3rem",
  "lineHeight": "1",
  "--tw-text-opacity": "1",
  "color": "rgba(0, 87, 0, var(--tw-text-opacity))",
  "marginBottom": "1rem",
  "@media (min-width: 768px)": {
    "fontSize": "4.5rem",
    "lineHeight": "1"
  }
});
const ArticleTitle = styled_components__WEBPACK_IMPORTED_MODULE_1___default().h1.withConfig({
  displayName: "ArticleSection__ArticleTitle",
  componentId: "sc-m6osfd-4"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(0, 87, 0, var(--tw-text-opacity))",
  "fontSize": "3rem",
  "lineHeight": "1",
  "fontWeight": "800",
  "marginBottom": "1rem",
  "@media (min-width: 1024px)": {
    "fontSize": "3.75rem",
    "lineHeight": "1"
  }
});
const ArticleBodyTitle = styled_components__WEBPACK_IMPORTED_MODULE_1___default().h1.withConfig({
  displayName: "ArticleSection__ArticleBodyTitle",
  componentId: "sc-m6osfd-5"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(0, 87, 0, var(--tw-text-opacity))",
  "fontSize": "3rem",
  "lineHeight": "1",
  "fontWeight": "800",
  "marginBottom": "1rem",
  "@media (min-width: 1024px)": {
    "fontSize": "3.75rem",
    "lineHeight": "1"
  }
});
const ArticleHeroP = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "ArticleSection__ArticleHeroP",
  componentId: "sc-m6osfd-6"
})(["", ""], {
  "fontSize": "1rem",
  "lineHeight": "1.5rem",
  "fontWeight": "400",
  "@media (min-width: 768px)": {
    "fontSize": "1.125rem",
    "lineHeight": "1.75rem"
  }
});
const ArticleHeroImgWrapper = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
  displayName: "ArticleSection__ArticleHeroImgWrapper",
  componentId: "sc-m6osfd-7"
})(["max-width:555px;"]);
const ArticleHeroImg = styled_components__WEBPACK_IMPORTED_MODULE_1___default().img.withConfig({
  displayName: "ArticleSection__ArticleHeroImg",
  componentId: "sc-m6osfd-8"
})(["", " max-width:95%;margin-top:0;margin-right:0;padding-right:0;border:0;max-width:100%;vertical-align:middle;display:inline-block;"], {
  "marginLeft": "0px",
  "objectFit": "contain",
  "@media (min-width: 768px)": {
    "marginLeft": "0.75rem"
  },
  "@media (min-width: 1024px)": {
    "marginLeft": "1.5rem"
  }
});

function ArticleSection({
  title,
  imgStart,
  header,
  id,
  text,
  img
}) {
  const tilt = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    return vanilla_tilt__WEBPACK_IMPORTED_MODULE_4___default().init(tilt.current, {
      reverse: true
    });
  }, []);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ArticleHeroSection, {
      id: id,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(___WEBPACK_IMPORTED_MODULE_2__/* .Container */ .W2, {
        children: [title ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ArticleTitle, {
          children: title
        }) : null, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(ArticleHeroRow, {
          imgStart: imgStart,
          title: title,
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(ArticleHeroCol, {
            children: [header ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ArticleBodyTitle, {
              children: header
            }) : null, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ArticleHeroP, {
              children: text
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ArticleHeroCol, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ArticleHeroImgWrapper, {
              ref: tilt,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                src: img,
                height: 542,
                width: 573,
                className: "object-contain flex self-end"
              })
            })
          })]
        })]
      })
    })
  });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArticleSection);

/***/ })

};
;