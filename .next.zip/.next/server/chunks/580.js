"use strict";
exports.id = 580;
exports.ids = [580];
exports.modules = {

/***/ 8580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(901);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
const _excluded = ["title", "pages", "tab", "onTabChange"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }








const TabsContainer = styled_components__WEBPACK_IMPORTED_MODULE_1___default()(___WEBPACK_IMPORTED_MODULE_2__/* .FlexContainer */ .Ej).withConfig({
  displayName: "PageTab__TabsContainer",
  componentId: "sc-smztf-0"
})(["", ";justify-content:", ";@media (max-width:768px){justify-content:", ";gap:10px;}@media (max-width:1024px){", "}@media (max-width:768px){", "}@media (max-width:500px){", "}"], {
  "fontSize": "0.75rem",
  "lineHeight": "1rem",
  "overflow": "hidden",
  "> :not([hidden]) ~ :not([hidden])": {
    "--tw-space-x-reverse": 0,
    "marginRight": "calc(1.25rem * var(--tw-space-x-reverse))",
    "marginLeft": "calc(1.25rem * calc(1 - var(--tw-space-x-reverse)))"
  },
  "marginLeft": "auto",
  "marginRight": "auto",
  "overflowX": "hidden",
  "marginTop": "-2.5rem",
  "@media (min-width: 768px)": {
    "marginTop": "-1.25rem"
  },
  "@media (min-width: 1024px)": {
    "fontSize": "1rem",
    "lineHeight": "1.5rem",
    "> :not([hidden]) ~ :not([hidden])": {
      "--tw-space-x-reverse": 0,
      "marginRight": "calc(5rem * var(--tw-space-x-reverse))",
      "marginLeft": "calc(5rem * calc(1 - var(--tw-space-x-reverse)))"
    }
  }
}, props => props.center && "space-between", ({
  center
}) => center && "center", {
  "paddingTop": "0px",
  "paddingBottom": "2.5rem"
}, {
  "paddingTop": "0px",
  "paddingBottom": "0px",
  "marginTop": "-1.25rem"
}, {
  "paddingTop": "1.25rem",
  "paddingBottom": "1.75rem"
});
const Tab = styled_components__WEBPACK_IMPORTED_MODULE_1___default().p.withConfig({
  displayName: "PageTab__Tab",
  componentId: "sc-smztf-1"
})(["", ";color:", ";border-color:#fff;border-style:solid;border-bottom-width:", ";bottom:", ";"], {
  "cursor": "pointer",
  "marginBottom": "0px",
  "paddingLeft": "0.25rem",
  "paddingRight": "0.25rem",
  "position": "relative",
  "fontSize": "0.75rem",
  "lineHeight": "1rem",
  "letterSpacing": "0.05em",
  "@media (min-width: 768px)": {
    "fontSize": "0.875rem",
    "lineHeight": "1.25rem"
  },
  "@media (min-width: 1024px)": {
    "fontSize": "0.875rem",
    "lineHeight": "1.25rem"
  }
}, ({
  active
}) => active ? "#FFF" : "#A3A3A3", ({
  active
}) => active ? "2px" : "0", ({
  center
}) => center ? "0" : "-2px");

const PageTab = _ref => {
  let {
    title = "",
    pages = [{
      tab: "",
      component: () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {})
    }],
    tab = 0,
    onTabChange
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  const {
    0: active,
    1: setActive
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(tab);
  const tabs = pages === null || pages === void 0 ? void 0 : pages.map(({
    tab
  }) => tab);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: "",
      children: [",", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(___WEBPACK_IMPORTED_MODULE_2__/* .Container */ .W2, {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(TabsContainer, _objectSpread(_objectSpread({}, props), {}, {
          children: [tabs === null || tabs === void 0 ? void 0 : tabs.map((tab, idx, component) => /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(Tab, _objectSpread(_objectSpread({}, props), {}, {
            key: idx,
            active: tab.length > 0 ? active === idx : false,
            onClick: () => {
              setActive(idx);

              if (onTabChange) {
                onTabChange(pages[idx].component);
              }
            }
          }), tab)), tabs === null || tabs === void 0 ? void 0 : tabs.map((tab, index) => {})]
        }))
      })]
    }), !onTabChange && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      children: pages[active].component
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageTab);

/***/ })

};
;