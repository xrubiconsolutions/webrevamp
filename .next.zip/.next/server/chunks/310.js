"use strict";
exports.id = 310;
exports.ids = [310];
exports.modules = {

/***/ 1310:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_L": () => (/* binding */ CardContainer),
/* harmony export */   "UK": () => (/* binding */ CardWrapper),
/* harmony export */   "H2": () => (/* binding */ H2),
/* harmony export */   "H3": () => (/* binding */ H3),
/* harmony export */   "kC": () => (/* binding */ Flex),
/* harmony export */   "ZC": () => (/* binding */ Div),
/* harmony export */   "rU": () => (/* binding */ Link),
/* harmony export */   "yi": () => (/* binding */ Contains)
/* harmony export */ });
/* unused harmony export ImageHolder */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);


const CardContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "styles__CardContainer",
  componentId: "sc-1nqbbjb-0"
})(["", ""], {
  "display": "grid",
  "gridTemplateColumns": "repeat(1, minmax(0, 1fr))",
  "gap": "1.25rem",
  "paddingBottom": "10rem",
  "paddingTop": "5rem",
  "@media (min-width: 768px)": {
    "gridTemplateColumns": "repeat(2, minmax(0, 1fr))"
  },
  "@media (min-width: 1024px)": {
    "gridTemplateColumns": "repeat(2, minmax(0, 1fr))"
  },
  "@media (min-width: 1280px)": {
    "gridTemplateColumns": "repeat(3, minmax(0, 1fr))"
  }
});
const CardWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "styles__CardWrapper",
  componentId: "sc-1nqbbjb-1"
})(["", ";background:", ";box-shadow:0px 9.34521px 27.4405px rgba(215,228,249,0.7);@media (max-width:768px){width:100%;}"], {
  "borderRadius": "0.125rem",
  "minHeight": "200px",
  "width": "100%",
  "paddingBottom": "1.25rem",
  "--tw-bg-opacity": "1",
  "backgroundColor": "rgba(255, 255, 255, var(--tw-bg-opacity))"
}, ({
  bg
}) => bg ? " #005700;" : "white");
const H2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2.withConfig({
  displayName: "styles__H2",
  componentId: "sc-1nqbbjb-2"
})(["", " transition:all 500ms ease-in-out;color:", ";text-decoration:", ";"], {
  "fontSize": "14px",
  "marginTop": "1.25rem",
  "paddingBottom": "0.75rem",
  "lineHeight": "35px",
  "fontWeight": "700",
  "letterSpacing": "0em",
  "@media (min-width: 768px)": {
    "fontSize": "1rem",
    "lineHeight": "1.5rem"
  }
}, ({
  col
}) => col ? "#fff" : "#005700", ({
  decoration
}) => decoration ? "none" : "underline");
const H3 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h3.withConfig({
  displayName: "styles__H3",
  componentId: "sc-1nqbbjb-3"
})(["", ""], {
  "fontSize": "0.75rem",
  "lineHeight": "1.25rem",
  "letterSpacing": "0.05em",
  "paddingTop": "0.5rem",
  "paddingBottom": "1.5rem",
  "fontWeight": "500"
});
const Flex = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "styles__Flex",
  componentId: "sc-1nqbbjb-4"
})(["", ""], {
  "display": "flex",
  "justifyContent": "space-between",
  "fontSize": "1.125rem",
  "lineHeight": "1.75rem"
});
const Div = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "styles__Div",
  componentId: "sc-1nqbbjb-5"
})(["", ""], {
  "display": "flex",
  "justifyContent": "space-between",
  "fontSize": "0.75rem",
  "lineHeight": "1rem",
  "fontWeight": "500"
});
const Link = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "styles__Link",
  componentId: "sc-1nqbbjb-6"
})([""]);
const ImageHolder = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(next_image__WEBPACK_IMPORTED_MODULE_1__["default"]).withConfig({
  displayName: "styles__ImageHolder",
  componentId: "sc-1nqbbjb-7"
})([""]);
const Contains = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "styles__Contains",
  componentId: "sc-1nqbbjb-8"
})(["", " color:", ";"], {
  "paddingLeft": "1.25rem",
  "paddingRight": "1.25rem"
}, ({
  col
}) => col ? " white;" : "black");

/***/ })

};
;