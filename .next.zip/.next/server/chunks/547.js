"use strict";
exports.id = 547;
exports.ids = [547];
exports.modules = {

/***/ 797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const InputField = styled_components__WEBPACK_IMPORTED_MODULE_1___default().input.withConfig({
  displayName: "input__InputField",
  componentId: "sc-gc6dwp-0"
})(["padding:0.3em 1em;border-radius:5px;font-size:13px;color:black;background:#ffffff;outline:none;box-shadow:none;border:1px solid #c2c2c2;transition:all 0.3s ease-out;position:relative;height:2.78rem;font-size:16px;font-weight:500;width:100%;&:focus{border:2px solid rgba(0,0,0,0.2);}"]);

const Input = ({
  value,
  type,
  id,
  onChange,
  placeholder,
  name,
  required,
  accept
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(InputField, {
      type: type,
      id: id,
      required: required,
      autoComplete: "off",
      name: name,
      placeholder: placeholder,
      value: value,
      onChange: onChange,
      accept: accept
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);

/***/ }),

/***/ 3147:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TJ": () => (/* binding */ careerRegister),
/* harmony export */   "jp": () => (/* binding */ faqRequest)
/* harmony export */ });
/* unused harmony exports constant, ApiRequest */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const constant = {
  // baseUrl: "https://packamserver.herokuapp.com/api",
  baseUrl: "https://pakam-staging.herokuapp.com/api"
}; // Resusable requests template

const ApiRequest = () => {
  const config = {
    baseURL: constant.baseUrl,
    headers: {
      "Content-Type": "multipart/form-data"
    }
  };
  const instance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create(config);
  return instance;
};
const careerRegister = formData => {
  return ApiRequest().post("/user/uploadresume", formData);
};
const faqRequest = data => {
  return ApiRequest().post("/v2/contactUs", data);
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;