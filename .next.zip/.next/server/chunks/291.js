"use strict";
exports.id = 291;
exports.ids = [291];
exports.modules = {

/***/ 8291:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(901);
/* harmony import */ var _PageTab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8580);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const TitleContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().header.withConfig({
  displayName: "BodyContainer__TitleContainer",
  componentId: "sc-1p9vski-0"
})(["width:100%;z-index:2;position:relative;background-position:center center;background-repeat:no-repeat;background-size:cover;padding:134px initial;align-items:flex-end;background-repeat:no-repeat;", ""], {
  "display": "flex",
  "flexDirection": "column",
  "alignItems": "center",
  "justifyContent": "center",
  "height": "100%",
  "minHeight": "200px",
  "> :not([hidden]) ~ :not([hidden])": {
    "--tw-space-y-reverse": 0,
    "marginTop": "calc(0px * calc(1 - var(--tw-space-y-reverse)))",
    "marginBottom": "calc(0px * var(--tw-space-y-reverse))"
  },
  "marginTop": "-1.25rem",
  "backgroundImage": "url('/svg/bg.svg')",
  "@media (min-width: 768px)": {
    "height": "330px"
  },
  "@media (min-width: 1024px)": {
    "height": "330px",
    "> :not([hidden]) ~ :not([hidden])": {
      "--tw-space-y-reverse": 0,
      "marginTop": "calc(1.25rem * calc(1 - var(--tw-space-y-reverse)))",
      "marginBottom": "calc(1.25rem * var(--tw-space-y-reverse))"
    }
  }
});
const TitleH1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1.withConfig({
  displayName: "BodyContainer__TitleH1",
  componentId: "sc-1p9vski-1"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "fontWeight": "800",
  "fontSize": "2.25rem",
  "lineHeight": "2.5rem",
  "@media (min-width: 1024px)": {
    "fontSize": "3.75rem",
    "lineHeight": "1"
  }
});
const TitleH2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1.withConfig({
  displayName: "BodyContainer__TitleH2",
  componentId: "sc-1p9vski-2"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "fontSize": "1.875rem",
  "lineHeight": "2.25rem",
  "textAlign": "center",
  "fontWeight": "800",
  "marginLeft": "auto",
  "marginRight": "auto",
  "paddingTop": "2rem",
  "@media (min-width: 768px)": {
    "fontSize": "2.25rem",
    "lineHeight": "2.5rem",
    "width": "90%"
  },
  "@media (min-width: 1024px)": {
    "fontSize": "3rem",
    "lineHeight": "1",
    "maxWidth": "80%",
    "paddingTop": "0.5rem"
  },
  "@media (min-width: 1280px)": {
    "maxWidth": "65%"
  }
});
const TitleH4 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1.withConfig({
  displayName: "BodyContainer__TitleH4",
  componentId: "sc-1p9vski-3"
})(["", ";"], {
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "fontSize": "1.875rem",
  "lineHeight": "2.25rem",
  "width": "100%",
  "textAlign": "center",
  "fontWeight": "800",
  "marginLeft": "auto",
  "marginRight": "auto",
  "@media (min-width: 768px)": {
    "fontSize": "3rem",
    "lineHeight": "1",
    "maxWidth": "80%",
    "paddingTop": "0px"
  },
  "@media (min-width: 1024px)": {
    "maxWidth": "65%",
    "paddingTop": "0px"
  }
});
const P = styled_components__WEBPACK_IMPORTED_MODULE_0___default().p.withConfig({
  displayName: "BodyContainer__P",
  componentId: "sc-1p9vski-4"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "fontSize": "1.125rem",
  "lineHeight": "1.75rem",
  "paddingTop": "2.5rem",
  "@media (min-width: 768px)": {
    "fontWeight": "500",
    "fontSize": "1.5rem",
    "lineHeight": "2rem"
  }
});
const BodySection = styled_components__WEBPACK_IMPORTED_MODULE_0___default().section.withConfig({
  displayName: "BodyContainer__BodySection",
  componentId: "sc-1p9vski-5"
})(["", ""], {
  "--tw-bg-opacity": "1",
  "backgroundColor": "rgba(248, 255, 244, var(--tw-bg-opacity))"
});
const P2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().p.withConfig({
  displayName: "BodyContainer__P2",
  componentId: "sc-1p9vski-6"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "fontSize": "0.75rem",
  "lineHeight": "1.5rem",
  "textAlign": "center",
  "width": "100%",
  "margin": "auto",
  "paddingTop": "1.75rem",
  "paddingBottom": "1.25rem",
  "@media (min-width: 768px)": {
    "fontSize": "1.25rem",
    "lineHeight": "1.75rem",
    "paddingTop": "2.5rem",
    "paddingBottom": "0.25rem"
  },
  "@media (min-width: 1024px)": {
    "width": "70%",
    "paddingTop": "0.5rem",
    "paddingBottom": "0px"
  },
  "@media (min-width: 1280px)": {
    "width": "50%"
  }
});
const ButtonContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "BodyContainer__ButtonContainer",
  componentId: "sc-1p9vski-7"
})(["", ""], {
  "@media (min-width: 768px)": {
    "paddingBottom": "2.5rem",
    "paddingTop": "1.25rem"
  }
});

const BodyContainer = ({
  title,
  text,
  tabNo,
  pages,
  smaller_title,
  smaller_text,
  isButton,
  careerTitle,
  children
}) => {
  const {
    0: tabBody,
    1: setTabBody
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(pages[0].component);

  const updateBody = elem => {
    setTabBody(elem);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(TitleContainer, {
      children: [" ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(P, {
        children: text
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(TitleH1, {
        children: title
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(TitleH2, {
        children: tabBody.type.name !== "ExpertReview" ? smaller_title : "What experts are saying about us"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(TitleH4, {
        children: careerTitle
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(___WEBPACK_IMPORTED_MODULE_1__/* .Container */ .W2, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(P2, {
          children: smaller_text
        })
      }), isButton ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(ButtonContainer, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(___WEBPACK_IMPORTED_MODULE_1__/* .Button */ .zx, {
          weight: false,
          primary: false,
          white: false,
          width: true,
          isBorder: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_scroll__WEBPACK_IMPORTED_MODULE_4__.Link, {
            to: "resume",
            spy: true,
            smooth: true,
            offset: -80,
            duration: 500,
            children: "Submit Resume"
          })
        })
      }) : "", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_PageTab__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        tab: tabNo !== undefined ? tabNo : 0,
        title: "",
        pages: pages,
        prevLink: "/",
        center: true // onTabChange={updateBody}
        ,
        onTabChange: elem => updateBody(elem)
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(BodySection, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(___WEBPACK_IMPORTED_MODULE_1__/* .Container */ .W2, {
        children: tabBody
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BodyContainer);

/***/ })

};
;