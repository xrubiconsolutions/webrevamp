"use strict";
exports.id = 534;
exports.ids = [534];
exports.modules = {

/***/ 4534:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wrapper": () => (/* binding */ Wrapper),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(901);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().div.withConfig({
  displayName: "user-privacy-notice__Wrapper",
  componentId: "sc-1vthvco-0"
})(["", " h2{", "}p{", "}h4{", "}ul{margin-top:10px;padding:3px 30px;}ul > li{list-style:disc;}em{font-style:italic;}span{color:black;display:block;}a{color:#87cefa;color:blue;}"], {
  "paddingTop": "1.75rem"
}, {
  "--tw-text-opacity": "1",
  "color": "rgba(0, 87, 0, var(--tw-text-opacity))",
  "fontSize": "1.25rem",
  "lineHeight": "1.75rem",
  "fontWeight": "500",
  "textAlign": "center",
  "marginBottom": "1.25rem"
}, {
  "paddingBottom": "1.25rem"
}, {
  "--tw-text-opacity": "1",
  "color": "rgba(0, 87, 0, var(--tw-text-opacity))",
  "fontSize": "1.125rem",
  "lineHeight": "1.75rem",
  "fontWeight": "500",
  "marginBottom": "0.5rem",
  "marginTop": "1.25rem"
});

const UserPrivacyPolicy = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: "bg-secondary",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_src_components__WEBPACK_IMPORTED_MODULE_1__/* .Container */ .W2, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(Wrapper, {
        className: "moderate_width",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
            children: "Privacy Notice for Users"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["Wastebanc powered by Pakam technology is an affiliate of Pakam Technology company (Company Registration Number 1796077) located at 127 Ogunlana Drive, Surulere Lagos, Nigeria is the controller of personal data of users and has appointed a Data Protection Officer", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
              href: "mailto:privacy@pakam.ng",
              children: " privacy@pakam.ng"
            }), ". The term \"us\" or \"we\" refers to the owner of the Wastebanc app powered by Pakam technology, a private limited company, founded in the Federal Republic of Nigeria.."]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "Wastebanc powered by Pakam technology is the Controller of your personal data unless otherwise stated below. Our postal address is : 127 Ogunlana Drive Surulere, Lagos Nigeria."
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["We have nominated a Data Protection Officer, and you can contact him at ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
              href: "mailto:privacy@pakam.ng",
              children: "privacy@pakam.ng"
            }), " or via any one of our postal addresses found in our website. Please mark the envelope \u2018Data Protection Officer\u2019."]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "The term \"us\" or \"we\" refers to the owner of the Wastebanc app powered by Pakam technology, is an affiliate of Pakam technology limited, a private limited company, founded in the Federal Republic of Nigeria. The term \u201Cyou\u201D or \u201Cyour\u201D refers to the users or agent who schedules, and/or receives a collection service through their Wastebanc app account."
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "1. Personal data we process"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "We only process information that we need, so we can provide you with the best of service on our collection marketplace."
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Contact details: things like name, phone number and e-mail address. For some of our services we might require a little more, like your home address."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Profile information: things like your profile picture, saved addresses, language and communication preferences when the time comes. For some of our services we might require a little more, like your driver license details."]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: " Geolocation: such as where you need a collection from."
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Payment information like the amount charged and the payment card used, including bank transfer"]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Communication and correspondence records such as when you engage with our in-app chat, or speak with our customer service agents."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Limited identification data of the device, like the IP address, on which the Wastebanc app has been installed"]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "Data about the usage of the collection services: things like data about schedule status, times and data about your conduct as assessed by agents."
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "2. Purpose of the processing"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "We process your personal data so we can provide you with one or more of our collection services:"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("b", {
                children: " We connect you with a Wastebanc Agent"
              }), ": We collect and process personal data for the purpose of connecting users with agent so you can be picked up and or dropped off your recyclable waste; or to show you where our nearest available Wastebanc drop-off locations are, such as our Wastebanc hub"]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("b", {
                children: "We make sure your schedule goes smoothly"
              }), ": We use geolocation data to make sure agent get to your location and resolve quality issues related to our services.", " "]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("b", {
                children: "We make sure the Wastebanc app is optimal:"
              }), " We use contact details to notify users and agents of updates to the Wastebanc app so you can keep using our services. We also gather limited data from the device that you use to connect you with our internet, mobile and telephone services, and to help keep your account safe through authentication and verification checks."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("b", {
                children: "We collect your payment:"
              }), " We obtain payment details to process users payment on behalf of agent for waste hailing.", " "]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("b", {
                children: "We maintain and promote standards:"
              }), " We collect data about schedule statuses, time and users ratings from agent feedback to encourage user safety, promote compliance with our terms and conditions, and make sure we\u2019re providing a quality and enjoyable service to everyone. Customer support data and correspondence is collected for the purposes of feedback, and resolving disputes and service quality issues."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("b", {
                children: "We keep you informed:"
              }), " Your name, phone number and email address will be used to communicate with you for things like letting you know that your schedule has been completed, sending you confirmation slips and receipts, and letting you know about important service updates such as when services are disrupted"]
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "We keep you informed:"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "We are allowed to use personal information in the ways described above if we have a proper reason to do so. We always make sure we have a good reason for doing anything with your data."
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Personal data is generally processed in order to provide the services contracted through the Wastebanc app with you. This means that to give you the service we promised you, and to meet our terms and conditions, we\u2019ll process your personal data to meet those obligations."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "We generally in other circumstances process your personal data relying on legitimate interest grounds. Legitimate interests include our commercial interests in providing an innovative, personalised, safe and profitable service to our users and partners, unless those interests are overridden by other interests. Our legitimate interests also include things like investigating and detecting fraudulent payments and other malicious activities, maintaining the security of our network and systems, and responding to suspected or actual criminal acts."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
              children: ["We may from time to time rely on alternative legal bases when:", " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
                  children: "it is necessary to comply with a legal obligation such as for processing data when the law requires it, including, for example, if there is a valid legal request to disclose personal information to a third party such as a Court or regulatory authority;"
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
                  children: [" ", "to protect your vital interests, or those of others, for example in the event of an emergency or an imminent threat to life; or"]
                }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
                  children: [" ", "you have given us clear consent to do so for another specific purpose in which you have been fully informed."]
                })]
              })]
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "If you choose not to give us personal information it may prevent us from fulfilling the contract with you, or stop us doing something expected of us in law. It may also mean that we cannot operate your account. For example, we collect and process the personal data submitted by you in the course of installing and using the Wastebanc app; refusing to share geolocation data via the App means we cannot direct a agent to your location for pick-up, nor can we show you one of our own drop-off location. We will not be able to fulfil our obligations to you in other circumstances, for example, should you refuse to undertake an identity verification check to ensure the integrity of your account, then the account may be suspended or blocked to prevent fraud."
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "4. Recipients"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["We only work with trusted partners and authorities. We only share when there is a proper reason to do so. We limit sharing to only that which is required. We do not sell your personal information.", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
                children: "The personal data of the generator is only disclosed to the collection company when they engage with a pickup or drop-off on in the Wastebanc app; in such a case, the agent will see the name, phone number (in some countries the number is masked) and geolocation data of the generator."
              })
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "5. Security and access"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "Any personal data collected in the course of providing our services is transferred to and stored in the data centres of Digital Ocean or any other cloud service provider we may choose to use for data storage."
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "Wastebanc Operations and partners can access personal data to the extent necessary to provide customer support in the respective area."]
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "For our research and scientific purposes, all data, like bulk geolocation data, is anonymised so you can never be identified from it"]
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "6. Your rights and controls"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["We want you to stay in control of your personal data. Wastebanc provides you with controls through the app where you can view your personal information including your profile data and trip history. We also offer in-app settings. Your right of access", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
                children: "\u2022 You can access your personal data via the Wastebanc app. You have the right to ask us for copies of your personal information. There are some exemptions, such as when we have to balance the rights of others, which means you may not always receive all the information we process."
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["Your right to rectification", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
                children: [" ", "You can access and update your personal data via the Wastebanc app. You have the right to ask us to rectify information you think is otherwise inaccurate. You also have the right to ask us to complete information you think is incomplete."]
              })
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "Your right to erasure"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "You have the right to ask us to erase your personal information in certain circumstances."
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["Your right to restriction of processing", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
                children: "You have the right to ask us to restrict the processing of your information in certain circumstances. This means that your data can only be used for certain things, such as legal claims or to exercise legal rights."
              })
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("p", {
            children: ["Your right to object to processing", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
                children: [" ", "You may have the right to object to processing if we are processing your information on the basis of legitimate interests. You may submit an objection to any automated decision we have made, and ask that a person reviews it."]
              })
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "Your right to data portability"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "*You have the right to ask that we transfer the information you gave us from one organisation to another, or give it to you, in certain circumstances. This only applies to information you have given us."
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "7. Retention"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "Bold retains user data for only as long as necessary for the purposes described above. This means that we retain different categories of data for different periods of time depending on the type of data, the collection service it relates to, and the purposes for which we collected the data."
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "Your personal data will be stored as long as you have an active generators account. If your account is closed, personal data will be deleted (according to our retention schedule and rules), unless such data is still required to meet any legal obligation, or for accounting, dispute resolution or fraud prevention purposes."
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "Financial data regarding collection services provided to passengers will be stored for three years after the last schedule. Data required for other accounting purposes will be stored for seven years after the last schedule."
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "In the event of a suspected criminal offence, fraudulent activity or false information having been provided, the data will be stored for up to 10 years."]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "In case of payment disputes, data will be retained until the claim is satisfied or the expiry date of such claims."
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "Schedule history data and the data about usage of collection services will be stored for three years, after which the data will be anonymized."
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
              children: "Please note that the deinstallation of Wastebanc app in your device does not cause the deletion of your personal data. If the Wastebanc app has not been used for three years, we\u2019ll get in touch and ask you to confirm whether you wish to keep your account active for future use. If no reply is received in a reasonable time, the account will be closed and personal data will be deleted unless such data is required for any purpose mentioned earlier in this privacy notice."
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "8. Direct marketing"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("ul", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("li", {
              children: "We may send direct marketing messages to your e-mail address and/or phone number when you have given us permission to do so, or under a soft opt-in basis. We may personalise direct marketing messages using information on how you use Wastebanc\u2019s services, such as how frequently you use the Wastebanc app, and your collection preferences."
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: [" ", "If you no longer wish to receive direct marketing messages, please click the \"Unsubscribe\" link in the footer of one of our emails, or opt-out in the profile section of the Wastebanc app. Easy."]
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "9. Automated decision making"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "We use help of automated decision-making in case of issuing warnings and implementing collection hailing service suspension. Using automated decision-making is less error-prone, more efficient and safer than using our employees. Data about your usage of the collection services (data about schedule status incl. cancellations and no-shows and data about your conduct as assessed by agent) is considered when assessing the need for a warning or suspension. collection hailing suspension will stay in force for 12 months, after which access to collection hailing service will be restored. You will always have the right for human review of the decision and to contest the decision, express your point of view and obtain an explanation by contacting our customer support in our app."
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "10. Dispute resolution"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("ul", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
              children: ["Disputes relating to the processing of personal data are resolved through customer support", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
                href: "info@pakam.ng",
                target: "_blank",
                children: "info@pakam.ng"
              }), " ", "in the first instance. You have the right to contact Bolt's Data Protection Officer", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("a", {
                href: "mailto:(privacy@pakam.ng)",
                target: "_blank",
                children: [" ", "privacy@pakam.ng", " "]
              }), "."]
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            children: "11. Making this notice great"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
            children: "We hope you have found this privacy notice easy to understand. Data protection laws are important. They strengthen rules and enhance your information rights. Many of these rules may appear complicated, but most are grounded in common sense. We take our responsibilities with your data seriously. Wastebanc will continue to make changes to this privacy notice as part of our commitment to protecting your privacy and affording you even more transparency."
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserPrivacyPolicy);

/***/ })

};
;