"use strict";
exports.id = 901;
exports.ids = [901];
exports.modules = {

/***/ 901:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W2": () => (/* binding */ Container),
/* harmony export */   "X2": () => (/* binding */ Row),
/* harmony export */   "sg": () => (/* binding */ Column),
/* harmony export */   "zx": () => (/* binding */ Button),
/* harmony export */   "Ej": () => (/* binding */ FlexContainer)
/* harmony export */ });
/* unused harmony export Title */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "components__Container",
  componentId: "sc-bopkp-0"
})(["z-index:1;width:100%;max-width:1400px;margin-right:auto;margin-left:auto;padding-right:50px;padding-left:50px;@media screen and (max-width:991px){padding-right:25px;padding-left:25px;}"]);
const Row = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "components__Row",
  componentId: "sc-bopkp-1"
})(["display:flex;margin-right:-15px;margin-bottom:-15px;margin-left:-15px;flex-wrap:wrap;align-content:stretch;align-items:center;flex-direction:row;"]);
const Column = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "components__Column",
  componentId: "sc-bopkp-2"
})(["margin-bottom:15px;padding-right:15px;padding-left:15px;flex:1;max-width:50%;flex-basis:50%;@media screen and (max-width:960px){max-width:100%;flex-basis:100%;}"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "components__Button",
  componentId: "sc-bopkp-3"
})(["", ";border-radius:", ";background:", ";white-space:nowrap;color:", ";padding:", ";font-weight:", ";border:", ";font-size:16px;outline:none;cursor:pointer;&:hover{transition:all 0.3s ease-out;background:#ffff;background:", ";}width:", ";@media screen and (max-width:960px){width:", ";}"], ({
  icons
}) => icons ? {
  "display": "flex",
  "alignItems": "center",
  "justifyContent": "center"
} : "", ({
  isBorder
}) => !isBorder ? "59.65px" : "10px", ({
  primary
}) => primary ? "#008300" : "#FFFFFF", ({
  white
}) => white ? "white" : "#008300", ({
  isBorder
}) => !isBorder ? "11px 46.5px" : "15px 60px", ({
  weight
}) => weight ? 500 : 700, ({
  white
}) => white ? "none" : "1px solid #b8d7c7", ({
  primary
}) => primary ? "#145C53 " : "#DCEBE3", ({
  width
}) => width ? "" : "100%", ({
  width
}) => width ? "" : "100%");
const FlexContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "components__FlexContainer",
  componentId: "sc-bopkp-4"
})(["", " ", ";"], {
  "display": "flex",
  "alignItems": "center"
}, {
  "cursor": "pointer"
});
const Title = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2.withConfig({
  displayName: "components__Title",
  componentId: "sc-bopkp-5"
})(["", ""], {
  "--tw-text-opacity": "1",
  "color": "rgba(248, 255, 244, var(--tw-text-opacity))",
  "fontSize": "1.125rem",
  "lineHeight": "1.75rem",
  "fontWeight": "800",
  "textAlign": "center"
});

/***/ })

};
;