(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(8819);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react-icons/lib"
var lib_ = __webpack_require__(2283);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/index.ts
var components = __webpack_require__(901);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/Navbar/index.tsx
2;













const AppNav = external_styled_components_default().nav.withConfig({
  displayName: "Navbar__AppNav",
  componentId: "sc-16b5wnc-0"
})(["background:", ";backdrop-filter:blur(10px);height:80px;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0px;z-index:99999;-webkit-transform:translateZ(0px);--tw-shadow:0 4px 6px -1px rgba(0,0,0,0.1),0 2px 4px -1px rgba(0,0,0,0.06);--tw-ring-offset-shadow:0 0 transparent;box-shadow:", ";backdrop-filter:blur(10px);@media screen and (max-width:960px){transition:0.8 all ease;}"], ({
  scrollNavbar
}) => scrollNavbar ? "rgba(255, 255, 255, 0.8)" : "#F8FFF4", ({
  scrollNavbar
}) => scrollNavbar ? "var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)" : "transparent");
const AppNavContainer = external_styled_components_default()(components/* Container */.W2).withConfig({
  displayName: "Navbar__AppNavContainer",
  componentId: "sc-16b5wnc-1"
})(["", " ", ""], {
  "display": "flex",
  "justifyContent": "space-between",
  "zIndex": "1"
}, components/* Container */.W2);
const AppNavLogo = external_styled_components_default().div.withConfig({
  displayName: "Navbar__AppNavLogo",
  componentId: "sc-16b5wnc-2"
})(["", ""], {
  "display": "flex",
  "alignItems": "center",
  "justifySelf": "start",
  "cursor": "pointer"
});
const MobileIcon = external_styled_components_default().div.withConfig({
  displayName: "Navbar__MobileIcon",
  componentId: "sc-16b5wnc-3"
})(["", " @media screen and (max-width:960px){", " transform:translate(-100%,60%);}"], {
  "display": "none"
}, {
  "display": "block",
  "position": "absolute",
  "top": "0px",
  "right": "0px",
  "fontSize": "1.875rem",
  "lineHeight": "2.25rem",
  "cursor": "pointer"
});
const NavMenu = external_styled_components_default().ul.withConfig({
  displayName: "Navbar__NavMenu",
  componentId: "sc-16b5wnc-4"
})(["", " list-style:none;margin-right:-24px;@media screen and (max-width:960px){", " top:80px;height:100vh;left:", ";transition:all 0.5s ease;}"], {
  "display": "flex",
  "alignItems": "center",
  "textAlign": "center"
}, {
  "display": "flex",
  "flexDirection": "column",
  "width": "100%",
  "position": "absolute",
  "opacity": "1",
  "--tw-bg-opacity": "1",
  "backgroundColor": "rgba(248, 255, 244, var(--tw-bg-opacity))"
}, ({
  click
}) => click ? 0 : "-100%");
const NavItem = external_styled_components_default().li.withConfig({
  displayName: "Navbar__NavItem",
  componentId: "sc-16b5wnc-5"
})(["", " border-bottom:2px solid transparent;letter-spacing:0.02em;font-size:16px;&:hover{font-weight:700;cursor:pointer;}@media screen and (max-width:960px){", " &:hover{font-weight:700;border:none;}}"], {
  "height": "80"
}, {
  "width": "100%"
});
const NavLinks = external_styled_components_default().a.withConfig({
  displayName: "Navbar__NavLinks",
  componentId: "sc-16b5wnc-6"
})(["", " padding:0.5rem 1rem;height:100%;&.active{border-bottom:none;font-weight:900;@media screen and (max-width:960px){border-bottom:none;font-weight:900;}}@media screen and (max-width:960px){", " &:hover{", " transition:all 0.3s ease;}}"], {
  "--tw-text-opacity": "1",
  "color": "rgba(34, 45, 51, var(--tw-text-opacity))",
  "display": "flex",
  "justifyContent": "center",
  "alignItems": "center"
}, {
  "textAlign": "center",
  "display": "table",
  "padding": "2rem",
  "width": "100%"
}, {
  "fontWeight": "700",
  "cursor": "pointer"
});
const NavItemBtn = external_styled_components_default().nav.withConfig({
  displayName: "Navbar__NavItemBtn",
  componentId: "sc-16b5wnc-7"
})(["@media screen and (max-width:960px){display:flex;justify-content:center;align-items:center;height:120px;margin-left:0;}"]);
const NavBtnLink = external_styled_components_default()(next_link["default"]).withConfig({
  displayName: "Navbar__NavBtnLink",
  componentId: "sc-16b5wnc-8"
})(["display:flex;justify-content:center;align-items:center;text-decoration:none;padding-block-end:8px 16px;height:100%;width:100%;border:none;outline:none;"]);

// function Navbar({ className = "" }: props) {
function Navbar() {
  const {
    0: scrollNavbar,
    1: setScrollNavbar
  } = (0,external_react_.useState)(false);
  const {
    0: primary,
    1: setPrimary
  } = (0,external_react_.useState)(true);
  const {
    0: white,
    1: setWhite
  } = (0,external_react_.useState)(true);
  const {
    0: click,
    1: setClick
  } = (0,external_react_.useState)(false);
  const {
    0: button,
    1: setButton
  } = (0,external_react_.useState)(true);

  const handleClick = () => setClick(!click);

  const closeMobileMenu = () => setClick(false);

  const appNav = (0,external_react_.useRef)(null);
  const router = (0,router_.useRouter)();

  const ChangeBackground = () => {
    if (window.pageYOffset >= 80) {
      setScrollNavbar(true);
    } else {
      setScrollNavbar(false);
    }
  };

  const toggleHome = () => {
    external_react_scroll_.animateScroll.scrollToTop();
  };

  const showButton = () => {
    if (window.innerWidth <= 960) {
      setButton(false);
    } else {
      setButton(true);
    }
  };

  (0,external_react_.useEffect)(() => {
    console.log(scrollNavbar, "i am here");
    window.addEventListener("scroll", ChangeBackground); // return () => {
    //   window.removeEventListener("scroll", ChangeBackground);
    // };
  }, []);
  (0,external_react_.useEffect)(() => {
    showButton();
    window.addEventListener("resize", showButton);
    return () => {
      window.removeEventListener("resize", showButton);
    };
  }, []);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(lib_.IconContext.Provider, {
      value: {
        color: "#3D4E4B"
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(AppNav, {
        scrollNavbar: scrollNavbar,
        ref: appNav,
        onScroll: () => {
          console.log("Hello");
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(AppNavContainer, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(AppNavLogo // className={classes("navbar-logo ")}
          , {
            onClick: toggleHome,
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              href: "/",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                src: "/svg/pkam-logo.svg",
                alt: "Pakam Logo",
                width: 120.68,
                height: 40
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(MobileIcon, {
            onClick: handleClick,
            children: click ? /*#__PURE__*/jsx_runtime_.jsx(fa_.FaTimes, {}) : /*#__PURE__*/jsx_runtime_.jsx(fa_.FaBars, {})
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(NavMenu, {
            onClick: handleClick,
            click: click,
            children: [/*#__PURE__*/jsx_runtime_.jsx(NavItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/about",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLinks, {
                  className: router.asPath == "/about" ? "active" : "",
                  onClick: closeMobileMenu,
                  children: "About us"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(NavItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/products",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLinks, {
                  className: router.asPath == "/products" ? "active" : "",
                  onClick: closeMobileMenu,
                  children: "Products"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(NavItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/careers",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLinks, {
                  className: router.asPath == "/careers" ? "active" : "",
                  onClick: closeMobileMenu,
                  children: "Careers"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(NavItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/news",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLinks, {
                  className: router.asPath == "/news" ? "active" : "",
                  onClick: closeMobileMenu,
                  children: "News"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(NavItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/faqs",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLinks, {
                  className: router.asPath == "/faqs" ? "active" : "",
                  onClick: closeMobileMenu,
                  children: "FAQs"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(NavItem, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/reviews",
                children: /*#__PURE__*/jsx_runtime_.jsx(NavLinks, {
                  className: router.asPath == "/reviews" ? "active" : "",
                  onClick: closeMobileMenu,
                  children: "Reviews"
                })
              })
            }), button ? null : /*#__PURE__*/jsx_runtime_.jsx(NavItemBtn, {
              children: /*#__PURE__*/jsx_runtime_.jsx(NavBtnLink, {
                href: "/contactUs",
                children: /*#__PURE__*/jsx_runtime_.jsx(components/* Button */.zx, {
                  primary: primary,
                  white: white,
                  onClick: closeMobileMenu,
                  children: "Contact Us"
                })
              })
            })]
          }), button && /*#__PURE__*/jsx_runtime_.jsx(NavItemBtn, {
            children: /*#__PURE__*/jsx_runtime_.jsx(NavBtnLink, {
              href: "/contactUs",
              children: /*#__PURE__*/jsx_runtime_.jsx(components/* Button */.zx, {
                primary: primary,
                white: white,
                children: "Contact Us"
              })
            })
          })]
        })
      })
    })
  });
}

/* harmony default export */ const components_Navbar = (Navbar);
;// CONCATENATED MODULE: ./src/components/Footer/footer.tsx







const FooterSection = external_styled_components_default().footer.withConfig({
  displayName: "footer__FooterSection",
  componentId: "sc-zoskpn-0"
})(["", ""], {
  "display": "flex",
  "alignItems": "center",
  "justifyContent": "center",
  "gap": "2rem",
  "--tw-bg-opacity": "1",
  "backgroundColor": "rgba(0, 87, 0, var(--tw-bg-opacity))"
});
const FooterContainer = external_styled_components_default().div.withConfig({
  displayName: "footer__FooterContainer",
  componentId: "sc-zoskpn-1"
})(["", ""], {
  "display": "grid",
  "alignItems": "flex-start",
  "gap": "1.25rem",
  "paddingTop": "2.5rem",
  "paddingBottom": "2.5rem",
  "@media (min-width: 1024px)": {
    "gridTemplateColumns": "repeat(3, minmax(0, 1fr))",
    "justifyContent": "center",
    "gap": "7rem"
  }
});
const FooterContainerList = external_styled_components_default().div.withConfig({
  displayName: "footer__FooterContainerList",
  componentId: "sc-zoskpn-2"
})(["", ""], {
  "> :not([hidden]) ~ :not([hidden])": {
    "--tw-space-y-reverse": 0,
    "marginTop": "calc(1.5rem * calc(1 - var(--tw-space-y-reverse)))",
    "marginBottom": "calc(1.5rem * var(--tw-space-y-reverse))"
  }
});
const FooterContainerListP = external_styled_components_default().p.withConfig({
  displayName: "footer__FooterContainerListP",
  componentId: "sc-zoskpn-3"
})(["", ""], {
  "fontSize": "1rem",
  "lineHeight": "1.5rem",
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  ":hover": {
    "cursor": "pointer"
  }
});
const FooterContainerCenter = external_styled_components_default().p.withConfig({
  displayName: "footer__FooterContainerCenter",
  componentId: "sc-zoskpn-4"
})(["", ""], {
  "> :not([hidden]) ~ :not([hidden])": {
    "--tw-space-y-reverse": 0,
    "marginTop": "calc(0.5rem * calc(1 - var(--tw-space-y-reverse)))",
    "marginBottom": "calc(0.5rem * var(--tw-space-y-reverse))"
  }
});
const FooterContainerListH6 = external_styled_components_default().h6.withConfig({
  displayName: "footer__FooterContainerListH6",
  componentId: "sc-zoskpn-5"
})(["", ""], {
  "fontSize": "1.125rem",
  "lineHeight": "1.75rem",
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "fontWeight": "700"
});
const FooterHr = external_styled_components_default().hr.withConfig({
  displayName: "footer__FooterHr",
  componentId: "sc-zoskpn-6"
})([""]);
const FooterFootNote = external_styled_components_default().div.withConfig({
  displayName: "footer__FooterFootNote",
  componentId: "sc-zoskpn-7"
})(["", ""], {
  "paddingBottom": "1rem",
  "paddingTop": "1.5rem",
  "fontSize": "0.875rem",
  "lineHeight": "1.25rem",
  "fontWeight": "100",
  "--tw-text-opacity": "1",
  "color": "rgba(255, 255, 255, var(--tw-text-opacity))",
  "textAlign": "center"
});
const AppContainer = external_styled_components_default().div.withConfig({
  displayName: "footer__AppContainer",
  componentId: "sc-zoskpn-8"
})(["", ""], {
  "display": "flex",
  "gap": "0.75rem"
});

const Footer = () => {
  return /*#__PURE__*/jsx_runtime_.jsx(FooterSection, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(components/* Container */.W2, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainer, {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainerList, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
            src: "/img/pakam_logo_white.png",
            alt: "Pakam Logo",
            width: 120.68,
            height: 40
          }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
            children: "Pakam enabling people, planet and profit"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(AppContainer, {
            children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "https://play.google.com/store/apps/details?id=com.pakamcustomer",
              target: "_blank",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                src: "/img/Google play.png",
                alt: "play store",
                width: 120,
                height: 40
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "https://apps.apple.com/ng/app/pakam-household-recycling-app/id1539296957",
              target: "_blank",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                src: "/img/apple.png",
                alt: "app store",
                width: 120,
                height: 40
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainerList, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(FooterContainerListH6, {
            children: "Legal"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainerCenter, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/cookie",
                children: "Cookie Policy"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/aggrement",
                children: "End User License Agreement"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/privacy",
                children: "Privacy Policy"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
                href: "/terms",
                children: "Terms and Conditions"
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainerList, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(FooterContainerListH6, {
            children: "Contact Us"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainerCenter, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: "127, Ogunlana Drive, Surulere"
            }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: "+234 - 912 261 6778"
            }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: "+234 - 708 664 6637"
            }), /*#__PURE__*/jsx_runtime_.jsx(FooterContainerListP, {
              children: "info@pakam.ng"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(AppContainer, {
              children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://web.facebook.com/people/Pakam/100067730415458/",
                target: "_blank",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                  src: "/img/facebook.png",
                  alt: "facebook",
                  width: 25.82,
                  height: 26.67
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://www.instagram.com/pakam_ng/?igshid=YmMyMTA2M2Y%3D",
                target: "_blank",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                  src: "/img/instagram.png",
                  alt: "instagram",
                  width: 25.82,
                  height: 26.67
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://twitter.com/_Pakam?t=x-7tBM5MyJeUK4oqR53uFg&s=09",
                target: "_blank",
                children: /*#__PURE__*/jsx_runtime_.jsx(next_image["default"], {
                  src: "/img/twitter.png",
                  alt: "twitter",
                  width: 25.82,
                  height: 26.67
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "https://api.whatsapp.com/message/7U3WYHMHI3HPF1?autoload=1&app_absent=0",
                target: "_blank",
                children: /*#__PURE__*/jsx_runtime_.jsx(fa_.FaWhatsapp, {
                  fontSize: 27,
                  color: "white"
                })
              })]
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(FooterHr, {}), /*#__PURE__*/jsx_runtime_.jsx(FooterFootNote, {
        children: "\xA9 2021 Pakam. All rights reserved"
      })]
    })
  });
};

/* harmony default export */ const footer = (Footer);
;// CONCATENATED MODULE: ./pages/_app.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(components_Navbar, {}), /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps)), /*#__PURE__*/jsx_runtime_.jsx(external_react_toastify_.ToastContainer, {
      hideProgressBar: false,
      limit: 1
    }), /*#__PURE__*/jsx_runtime_.jsx(footer, {})]
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 5429:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 2283:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/lib");

/***/ }),

/***/ 3094:
/***/ ((module) => {

"use strict";
module.exports = require("react-scroll");

/***/ }),

/***/ 1187:
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,676,63,901], () => (__webpack_exec__(136)));
module.exports = __webpack_exports__;

})();